#ifndef USERSETTINGS_H
#define USERSETTINGS_H

///////////////////////////////////////////////////////
// Settings to alter for your own version

#define SETTING_NAME	"DirectX Plasma"
#define SETTING_ICON	"PlasmaIcon"

// Main function (prototype and define)
DWORD PASCAL PlasmaProc(void*);
#define ThreadFunc		PlasmaProc

///////////////////////////////////////////////////////
#endif // USERSETTINGS_H