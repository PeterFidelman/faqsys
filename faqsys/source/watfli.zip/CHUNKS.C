/****************************************************************************
 *                                                                          *
 * This is the module to process the .FLI chunks                            *
 * FLI Player                                                               *
 * By TH/21/1/97                                                            *
 *                                                                          *
 ****************************************************************************/

#include "fli.h"

extern UBYTE            *flidata;       
extern UBYTE            *dbuffer;
extern DWORD            numframes;      
extern FLIPALETTE       palette[256];

/****************************************************************************
 *                                                                          *
 * Function: ProcessColorChunk                                              *
 * Purpose : Decode and play a FLI_COLOR chunk                              *
 * Input   : Src data                                                       *
 * Output  : Nothing                                                        *
 *                                                                          *
 ****************************************************************************/

void ProcessColorChunk(UBYTE *src)
{
        WORD            packs;
        UBYTE           skip;
        UBYTE           change;
        DWORD           n, curc = 0, count;

        packs = *((WORD *)src);
        src += 2;

        for(n=0; n<packs; n++) {
                skip = *src++;
                change = *src++;
                curc += skip;
                if(change == 0)
                        count = 256;
                else
                        count = change;
                outp(0x3C8, curc);

                while(count--) {
                        palette[curc].r = *src++;
                        outp(0x3C9, palette[curc].r);

                        palette[curc].g = *src++;
                        outp(0x3C9, palette[curc].g);

                        palette[curc].b = *src++;
                        outp(0x3C9, palette[curc].b);

                        curc++;
                }
        }
}

/****************************************************************************
 *                                                                          *
 * Function: ProcessLcChunk                                                 *
 * Purpose : Process a FLI_LC chunk                                         *
 * Input   : Src data                                                       *
 * Output  : Nothing                                                        *
 *                                                                          *
 ****************************************************************************/

void ProcessLcChunk(UBYTE *src)
{
        WORD            nochange, change;
        DWORD           y, n;
        UBYTE           *dest;
        UBYTE           packets, skip;
        SBYTE           size;

        nochange = *((WORD *) src);
        src += 2;
        change = *((WORD *) src);
        src += 2;

        y = nochange;
        for(n=0; n<change; n++, y++) {
                dest = dbuffer + 320*y;
                packets = *src++;

                while(packets--) {
                        skip = *src++;
                        size = *src++;
                        if(size > 0) {
                                dest += skip;
                                memcpy(dest, src, size);
                                dest += size;
                                src += size;
                        } else {
                                dest += skip;
                                memset(dest, *src++, -size);
                                dest += -size;
                        }
                }
        }
}

/****************************************************************************
 *                                                                          *
 * Function: ProcessBlackChunk                                              *
 * Purpose : Process a FLI_BLACK chunk                                      *
 * Input   : Src data                                                       *
 * Output  : Nothing                                                        *
 *                                                                          *
 ****************************************************************************/

void ProcessBlackChunk(UBYTE *src)
{
        memset(dbuffer, 0, 64000);
}

/****************************************************************************
 *                                                                          *
 * Function: ProcessBrunChunk                                               *
 * Purpose : Process a FLI_BRUN chunk                                       *
 * Input   : Src data                                                       *
 * Output  : Nothing                                                        *
 *                                                                          *
 ****************************************************************************/

void ProcessBrunChunk(UBYTE *src)
{
        SBYTE           size;
        UBYTE           packets;
        UBYTE           *dest;
        LONG            y = 0;
        WORD            lines;

        lines = 200;

        while(lines--) {
                packets = *src++;
                dest = dbuffer + 320*y;
        
                while(packets--) {
                        size = *src++;
                        if(size > 0) {
                                memset(dest, *src++, size);
                                dest += size;
                        } else {
                                memcpy(dest, src, -size);
                                dest += -size;
                                src += -size;
                        }
                }
                y++;
        }
}

/****************************************************************************
 *                                                                          *
 * Function: ProcessCopyChunk                                               *
 * Purpose : Process the FLI_COPY chunk                                     *
 * Input   : Src data                                                       *
 * Output  : Nothing                                                        *
 *                                                                          *
 ****************************************************************************/

void ProcessCopyChunk(UBYTE *src)
{
        memcpy(dbuffer, src, 64000);
}

/****************************************************************************
 *                                                                          *
 * Function: ProcessDeltaChunk                                              *
 * Purpose : Process the FLI_DELTA chunk                                    *
 * Input   : Src data                                                       *
 * Output  : Nothing                                                        *
 *                                                                          *
 ****************************************************************************/

void ProcessDeltaChunk(UBYTE *src)
{
        SWORD           packets;
        WORD            lines, data, *wdest;
        LONG            y = 0, count;
        UBYTE           *dest, skip;
        SBYTE           size;

        lines = *((WORD *) src);
        src += 2;

        while(lines--) {
                packets = *((WORD *) src);
                src += 2;
                if(packets < 0) {
                        y += -packets;
                } else {
                        dest = dbuffer + 320 * y;
                        skip = *src++;
                        size = *src++;
                        if(size > 0) {
                                memcpy(dest, src, size * 2);
                                dest += size*2;
                                src += size*2;
                        } else {
                                data = *((WORD *) src);
                                src += 2;
                                count = -size;
                                wdest = (WORD *) dest;
                                while(count--)
                                        *wdest++ = data;
                                dest += (-size)*2;
                        }
                }
        }
}

/****************************************************************************
 *                                                                          *
 * Function: Process256ColorChunk                                           *
 * Purpose : Process the FLI_256_COLOR chunk                                *
 * Input   : Src data                                                       *
 * Output  : Nothing                                                        *
 *                                                                          *
 ****************************************************************************/

void Process256ColorChunk(UBYTE *src)
{
        WORD            packs;
        UBYTE           skip;
        UBYTE           change;
        DWORD           n, curc = 0, count;

        packs = *((WORD *)src);
        src += 2;

        for(n=0; n<packs; n++) {
                skip = *src++;
                change = *src++;
                curc += skip;
                if(change == 0)
                        count = 256;
                else
                        count = change;
                outp(0x3C8, curc);

                while(count--) {
                        palette[curc].r = *src++ >> 2;
                        outp(0x3C9, palette[curc].r);

                        palette[curc].g = *src++ >> 2;
                        outp(0x3C9, palette[curc].g);

                        palette[curc].b = *src++ >> 2;
                        outp(0x3C9, palette[curc].b);

                        curc++;
                }
        }
}

