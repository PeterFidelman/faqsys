/****************************************************************************
 *                                                                          *
 * FLI Player                                                               *
 * By TH/21/1/97                                                            *
 * This is free software; an original work. Information to make this was    *
 * taken from a document by Mike Haaland. This code is intended as teaching *
 * material; both how to use the Watcom C/C++ compiler, and how to display  *
 * .FLI files. This file may not be used for commercial purposes, without   *
 * consent of the author; it may however be extended by other individuals,  *
 * provided they retain this notice, and original authors credits. It may   *
 * be ported to other operating systems and compilers without consent of    *
 * the author; further it can be incorporated into free/public domain/GNU   *
 * projects only - but *NOT* shareware, without consent                     *
 *                                                                          *
 * -- Tom Hammersey, 21/1/97, tomh@globalnet.co.uk                          *
 *                                                                          *
 ****************************************************************************/

#include "fli.h"

/****************************************************************************
 *                                                                          *
 * Global data for file; the .FLI file will be loaded totally into memory,  *
 * there will be a double buffered screen, and palette data will be         *
 * retained in a global structure.                                          *
 *                                                                          *
 ****************************************************************************/

UBYTE                   *flidata;       /* Data for .FLI file */
UBYTE                   *curptr;        /* Current position in data */
UBYTE                   *dbuffer;      /* The New Frame */
DWORD                   numframes;      /* Frames in animation */
LONG                    waitcount;      /* Frames to wait */
LONG                    loop = 0;
FLIPALETTE              palette[256];

/****************************************************************************
 *                                                                          *
 * Now code to display the file. This should be pretty portable between     *
 * compilers                                                                *
 *                                                                          *
 ****************************************************************************/

/****************************************************************************
 *                                                                          *
 * Function: OpenFLIFile                                                    *
 * Purpose : Open up a .fli file, return a void pointer to data if was      *
 *         : successful, else return a NULL pointer                         *
 * Input   : filename                                                       *
 * Output  : Void pointer to data (no disk I/O will be done in program)     *
 *                                                                          *
 ****************************************************************************/

void *OpenFLIFile(UBYTE *filename)
{
        FILE            *file;
        FLIHDR          hdr;
        void            *buffer;

        file = fopen(filename, "rb");
        if(file == NULL) {
                printf("Couldn't open file: %s\n", filename);
                return NULL;
        }

        fread(&hdr, sizeof(FLIHDR), 1, file);
        if(hdr.magic != 0xAF11) {
                fclose(file);
                printf("This is not a .FLI file. Note this player doesn't"
                       " play .FLCs\n");
                return NULL;
        }

        printf("Frames  : %d\n", hdr.frames);
        printf("Width   : %d\n", hdr.width);
        printf("Height  : %d\n", hdr.height);
        printf("Depth   : %d\n", hdr.depth);
        printf("Flags   : %Xh\n", hdr.flags);
        printf("Size    : %d\n", hdr.size - 128);
        printf("\nReading in entire .FLI file...\n");

        buffer = (UBYTE *) malloc(hdr.size - 128);
        if(buffer == NULL) {
                printf("Not enough memory to load file. Ensure you have"
                       " enough RAM to load the file\n");
                fclose(file);
                return NULL;
        }

        fread(buffer, sizeof(UBYTE), hdr.size - 128, file);
        printf("Buffer read complete\n");

        numframes = hdr.frames;
        waitcount = hdr.speed;

        return buffer;
}

/****************************************************************************
 *                                                                          *
 * Function: InitGraphics                                                   *
 * Purpose : Initalize VGA graphics mode                                    *
 * Input   : Nothing                                                        *
 * Output  : TRUE/FALSE                                                     *
 *                                                                          *
 ****************************************************************************/

BOOLEAN InitGraphics(void)
{
        union REGS      regs;

        dbuffer = (UBYTE *) malloc(64000);
        if(dbuffer == NULL) {
                printf("Couldn't allocate new frame\n");
                return FALSE;
        }

        memset(dbuffer, 0, 64000);

        regs.x.eax = 0x13;
        int386(0x10, &regs, &regs);

        return TRUE;
}       

/****************************************************************************
 *                                                                          *
 * Function: CloseGraphics                                                  *
 * Purpose : Close down graphics mode                                       *
 * Input   : Nothing                                                        *
 * Output  : TRUE/FALSE                                                     *
 *                                                                          *
 ****************************************************************************/

BOOLEAN CloseGraphics(void)
{
        union REGS      regs;

        free(dbuffer);

        regs.x.eax = 3;
        int386(0x10, &regs, &regs);

        return TRUE;
}

/****************************************************************************
 *                                                                          *
 * Function: WaitRetrace                                                    *
 * Purpose : Wait for a bunch of retraces, slow the animation down          *
 * Input   : Number to wait for                                             *
 * Output  : Nothing returned                                               *
 *                                                                          *
 ****************************************************************************/

void WaitRetrace(LONG count)
{
        while(count--) {
                while(inp(0x3DA) & 8);
                while((inp(0x3DA) & 8) == 0);
        }
}

/****************************************************************************
 *                                                                          *
 * Function: ReadFLIFrame                                                   *
 * Purpose : Copy a frame into a buffer, from main data buffer              *
 * Input   : Buffer pointer                                                 *
 * Output  : TRUE/FALSE                                                     *
 *                                                                          *
 ****************************************************************************/

BOOLEAN ReadFLIFrame(FLIFRAME *frame)
{
        memcpy(frame, curptr, sizeof(FLIFRAME));
        curptr += sizeof(FLIFRAME);

        if(frame->magic != 0xF1FA) {
                printf("Not a frame\n");
                printf("Found %X\n", frame->magic);
                getch();
                return FALSE;
        }

        return TRUE;
}

/****************************************************************************
 *                                                                          *
 * Function: ProcessFrame                                                   *
 * Purpose : Process a FLI frame                                            *
 * Input   : FLI Frame pointer                                              *
 * Output  : TRUE/FALSE                                                     *
 *                                                                          *
 ****************************************************************************/

BOOLEAN ProcessFrame(FLIFRAME *frame)
{
        DWORD           chunk;
        FLICHUNK        flichunk;

        for(chunk=0; chunk<frame->chunks; chunk++) {
                memcpy(&flichunk, curptr, sizeof(FLICHUNK));
                curptr += sizeof(FLICHUNK);
/*
                printf("Type %X\n", flichunk.type);
*/
                switch(flichunk.type) {
                        case FLI_COLOR:
                                ProcessColorChunk(curptr);
                                break;
                        case FLI_LC:
                                ProcessLcChunk(curptr);
                                break;
                        case FLI_BLACK:
                                ProcessBlackChunk(curptr);
                                break;
                        case FLI_BRUN:
                                ProcessBrunChunk(curptr);
                                break;
                        case FLI_COPY:
                                ProcessCopyChunk(curptr);
                                break;
                        case FLI_DELTA:
                                ProcessDeltaChunk(curptr);
                                break;
                        case FLI_256_COLOR:
                                Process256ColorChunk(curptr);
                                break;
                }

/*
                printf("Size: %d\n", flichunk.size);
                if(getch() == 27)
                        return FALSE;
*/
                curptr += flichunk.size - sizeof(FLICHUNK);
        }

        return TRUE;
}

/****************************************************************************
 *                                                                          *
 * Function: PlayFLIAnimation                                               *
 * Purpose : Play the .FLI animation                                        *
 * Input   : Nothing                                                        *
 * Output  : Nothing returned                                               *
 *                                                                          *
 ****************************************************************************/

void PlayFLIAnimation(void)
{
        DWORD           frame;
        FLIFRAME        fliframe;

        do {
                curptr = flidata;
                for(frame=0; frame<numframes; frame++) {
                        if(!ReadFLIFrame(&fliframe))
                                return;
                        if(!ProcessFrame(&fliframe))
                                return;
                        memcpy((UBYTE *) 0xA0000L, dbuffer, 64000);
                        WaitRetrace(waitcount);
                        if(kbhit())
                                if(getch() == 27)
                                        return;
                }
        } while(loop);
}

/****************************************************************************
 *                                                                          *
 * Function: ParseCommandLine                                               *
 * Purpose : Parse the command line                                         *
 * Input   : Command line arg array                                         *
 * Output  : Various flags set                                              *
 *                                                                          *
 ****************************************************************************/

void ParseCommandLine(int argc, char *argv[])
{
        LONG            n;

        for(n=2; n<=argc; n++) {
                if(!stricmp(argv[n], "-loop"))
                        loop = 1;
        }
}

/****************************************************************************
 *                                                                          *
 * Function: main                                                           *
 * Purpose : main body of code                                              *
 * Input   : Command line arguements                                        *
 * Output  : 1 if error, else 0                                             *
 *                                                                          *
 ****************************************************************************/

int main(int argc, char *argv[])
{
        if(argc < 2) {
                printf("You must type fli filename.fli [options]\n");
                return 1;
        }

        ParseCommandLine(argc, argv);

        if(!(flidata = OpenFLIFile(argv[1]))) {
                printf("Error load .FLI file\n");
                return 1;
        }

        if(!InitGraphics()) {
                printf("Graphics initialization error\n");
                return 1;
        }

        PlayFLIAnimation();

        if(!CloseGraphics()) {
                printf("Graphics shutdown error\n");
                return 1;
        }

        return 0;
}

