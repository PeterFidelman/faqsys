An optimal pathfinder for vehicles in real-world digital terrain maps
---------------------------------------------------------------------
by F. Markus J�nsson

Files:
PathFinder - p0.doc	The 1st part; abstract, preface, contents
PathFinder - p1.doc	The 2nd part; sections 1 though 7

Both the files are in Ms Word 97 format. If you have an older version 
of Word, then you can download a converter from microsoft's www site.

/ Markus
