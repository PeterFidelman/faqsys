Other\windows.doc	Old article I wrote on how windows works
Tut1\WinTut1.doc	Microsoft WordPad file with intro and theory
     Demo.exe		Sample program
     Demo.mak		MakeFile for app
     Demo.cpp/.h	Main program file
     stdafx.h		Global includes
     Star.cpp/.h	Class to move and draw starfield, used by demo.cpp
 