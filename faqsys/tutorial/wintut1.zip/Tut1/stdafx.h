#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <dos.h>
