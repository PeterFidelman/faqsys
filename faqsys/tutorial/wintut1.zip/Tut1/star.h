#define g_nMaxStars 1000


class CStar
{
public :
	int m_nXPos, m_nYPos, m_nZPos;
	int m_nOldX, m_nOldY;
}; // Details of each individual star


class CStarField
{
public :
	CStarField();
	~CStarField();

	CStar	*m_cStar[g_nMaxStars];	// Possible pointers to stars, don't allocate memory yet

	BOOL	SetUpStars(int nNumStars);
	void 	SetDimensions (int nWidth, int nHeight);

	void	DrawStarField (HDC pDC);
	void	MoveStarField (int nXofs, int nYofs, int nZofs);
	
private :
	int		m_nTotStars;
	int		m_nCenterX, m_nCenterY;
};