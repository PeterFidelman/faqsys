#include "star.h"

CStarField	g_csStars;
