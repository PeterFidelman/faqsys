
void SetVGAMode(int mode)
/*
  some common ones are
	0x03 - Text mode
	0x07 - Monochrome
	0x13 - 320x200x256
*/
{
  _asm {
	mov ax,mode
	int 10h
  }
}

void SetCursor(unsigned char X, unsigned char Y)
{
_asm {
 mov ah,02h
 xor bh,bh
 mov dh,[Y]
 mov dl,[X]
 int 10h
}
}


void WriteChar(unsigned char chnr,unsigned char color)
{
_asm {
 mov ah,09h
 mov al,[chnr]
 mov bh,0
 mov bl,[color]
 mov cx,1
 int 10h
}
}



void WriteXY(unsigned char x, unsigned char y, unsigned char *str,unsigned char	color)
{
	unsigned char i;

	SetCursor(x,y);
	for( i=0; i <strlen(str); ++i) {
		WriteChar(str[i],color);
		SetCursor((unsigned char)(x+i),y);
	}
}
