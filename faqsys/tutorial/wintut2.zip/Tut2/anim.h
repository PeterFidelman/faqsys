class CAnimatedPic
{
public :
	CAnimatedPic::CAnimatedPic()
	{
		m_nCurFrame = RANDOM (0, 13);
		m_nFrameCount = 3;
	}		//	Constructor
	
	int	m_nCurFrame;
			//	Current frame associated with this picture

	void PositionImage (int nX, int nY)
	{
		m_nXPos = nX;
		m_nYPos = nY;
		m_nFrameCount--;
		if (m_nFrameCount == 0)	//	Only alter the frame every five frames (otherwise too quick!)
		{
			m_nCurFrame = (m_nCurFrame + 1) % g_nNumFrames;
			m_nFrameCount = 5;
		}
	}
	
	int GetXPos () { return m_nXPos; }
	int GetYPos () { return m_nYPos; }

private:
	int		m_nXPos, m_nYPos;	
	int		m_nFrameCount;
};		//	Simple little class to handle the individual pictures flying around
		//	Should have it's own .cpp file, but hey, I'm lazy
