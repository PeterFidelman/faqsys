#include "stdafx.h"
#include "sprite.h"

CSprite::CSprite()
{
	m_hbmImage = NULL;
}

CSprite::~CSprite()
{
	if (m_hbmImage)
		DeleteObject (m_hbmImage);
			//	If InitImage has been called, clean up
}


void CSprite::InitImage (HINSTANCE hInst, WORD nIDResource, int nWidth, int nHeight)
{
	m_hbmImage = LoadBitmap(hInst, MAKEINTRESOURCE(nIDResource));
	m_nWidth = nWidth;
	m_nHeight = nHeight;
}		// 	Loads the image

void CSprite::DrawImage (HDC pDC, int nX, int nY)
{
	HDC	tempDC;
	tempDC = CreateCompatibleDC (NULL);

	HBITMAP bOld = (HBITMAP)SelectObject (tempDC, m_hbmImage);
	BitBlt (pDC, nX, nY, m_nWidth, m_nHeight, tempDC, 0, 0, SRCCOPY);
	SelectObject (tempDC, bOld);

	DeleteDC (tempDC);
}		//	Draws the image
