#define g_nNumFrames	14
#define g_nNumPictures	30

#include "sprite.h"
#include "anim.h"



CSprite		g_szcsPicture[g_nNumFrames];
CAnimatedPic	g_szcapItem[g_nNumPictures];


int			g_nWinWidth, g_nWinHeight;
		//	Screen width and height
		