class CSprite
{
public :
	CSprite ();
	~CSprite ();
	
	void InitImage (HINSTANCE hInst, WORD nIDResource, int nWidth, int nHeight);
			//	Initialize image from resource

	void DrawImage (HDC pDC, int nX, int nY);
			//	Paint image at set location
	
private :

	HBITMAP	m_hbmImage;
	int		m_nWidth, m_nHeight;
};
	//	Encloses information for our image
	