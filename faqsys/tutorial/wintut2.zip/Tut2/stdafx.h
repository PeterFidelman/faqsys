#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <dos.h>

#define RANDOM( min, max ) ((rand() % (int)(((max)+1) - (min))) + (min))
