//**************************************************************************
//
// 3D Viewing System Tutorial Release 1 - Copright (c) 1998, Gautam N. Lad.
//
// Released January 10, 1998
//
// This demonstration program is part of the GNL3D_R1.ZIP tutorial package.
// DO NOT distribute this program separately.  Other than that, you are
// allowed to experiment with this program and modify it as you wish.
// DO NOT however, distribute your modified version with the original
// version.
//
// Gautam N. Lad
// E-Mail: 	gautam@interlog.com
// Website: http://www.interlog.com/~gautam
//
//**************************************************************************

#define OneDeg        0.0174532925199432955		// Equivalent to pi/180

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <conio.h>

// Vector structure
typedef struct {
	float x, y, z;
} Vector;

// Camera structure
typedef struct {
	Vector LookFrom, LookAt;
	float FOV;
} Camera;

// Matrix structure
typedef struct {
	float r[3][3];
	float t[3];
} Matrix;


// --------------------------------------------------------------------------
// Find magnitude of vector 'a'.  'mag' holds calculated value
// --------------------------------------------------------------------------
void Magnitude(Vector *a, float *mag)
{
(*mag) = sqrt((a->x*a->x) + (a->y*a->y) + (a->z*a->z));
}


// --------------------------------------------------------------------------
// Normalizes vector 'a' (turn it into a unit vector)
// --------------------------------------------------------------------------
void Normalize(Vector *a)
{
float m;  

Magnitude(a, &m); // find magnitude of vector 'a'

a->x=a->x/m;
a->y=a->y/m;
a->z=a->z/m;
}


// --------------------------------------------------------------------------
// Computes Dot Product of vector 'a' and 'b'.
// 'dot' holds the cosine of the calculated angle.  
// To convert value to angle, use this:
// angle = acos(value)/(pi/180);
// --------------------------------------------------------------------------
void Dot_Product(Vector *a, Vector *b, float *dot)
{
Normalize(a);
Normalize(b);
(*dot) = (a->x*b->x + a->y*b->y + a->z*b->z);
}


// --------------------------------------------------------------------------
// Computes the Cross Product of vector 'a' and 'b'.
// Calculated vector, 'c', is then normalized.
// --------------------------------------------------------------------------
void Cross_Product(Vector *a, Vector *b, Vector *c)
{
c->x = (a->y*b->z)-(a->z*b->y);
c->y = (a->z*b->x)-(a->x*b->z);
c->z = (a->x*b->y)-(a->y*b->x);

Normalize(c);
}


// --------------------------------------------------------------------------
// Applies matrix 'm' to vector 'v'.
// --------------------------------------------------------------------------
void Apply_Matrix_To_Vector(Matrix *m, Vector *v)
{
v->x = (v->x*m->r[0][0]) + (v->y*m->r[0][1]) + (v->z*m->r[0][2]) + m->t[0];
v->y = (v->x*m->r[1][0]) + (v->y*m->r[1][1]) + (v->z*m->r[1][2]) + m->t[1];
v->z = (v->x*m->r[2][0]) + (v->y*m->r[2][1]) + (v->z*m->r[2][2]) + m->t[2];
}


// --------------------------------------------------------------------------
// Gets a matrix based on the camera data.  A pointer to the
// camera is passed in 'c' and the resulting matrix is stored
// in 'm'.
// --------------------------------------------------------------------------
void Get_Camera_Matrix(Camera *c, Matrix *m)
{
Vector U={1,0,0}, V={0,1,0}, N={0,0,-1};
float v;

  N.x = c->LookFrom.x-c->LookAt.x;
  N.y = c->LookFrom.y-c->LookAt.y;
  N.z = c->LookFrom.z-c->LookAt.z;
  Normalize(&N);
  N.x=-N.x; N.y=-N.y; N.z=-N.z;
 
  Dot_Product(&V,&N,&v);
  V.x-=(v*N.x);  V.y-=(v*N.y);  V.z-=(v*N.z);
  Normalize(&V);
   
  Cross_Product(&V,&N,&U);

  m->r[0][0] = U.x; m->r[0][1] = U.y; m->r[0][2] = U.z;
  m->r[1][0] = V.x; m->r[1][1] = V.y; m->r[1][2] = V.z;
  m->r[2][0] = N.x; m->r[2][1] = N.y; m->r[2][2] = N.z;

  m->t[0] = -(U.x*c->LookFrom.x + U.y*c->LookFrom.y + U.z*c->LookFrom.z);
  m->t[1] = -(V.x*c->LookFrom.x + V.y*c->LookFrom.y + V.z*c->LookFrom.z);
  m->t[2] = -(N.x*c->LookFrom.x + N.y*c->LookFrom.y + N.z*c->LookFrom.z);
}

// --------------------------------------------------------------------------
// Applies the camera matrix 'm' to the vector 'v'.  This function also
// calculates the screen location of the calculated vector and
// passes the screen x and y co-ordinates to the variables 'sx', and
// 'sy'.  You must also pass in the 'FOV' of the camera being used
// You must then supply the SCREEN_WIDTH and SCREEN_HEIGHT.  Basically, these
// are the size of the viewport the image will be projected on.
// --------------------------------------------------------------------------
void Apply_Camera_Matrix(Matrix *m, Vector *v, float *sx, float *sy, 
												 float *FOV, int SCREEN_WIDTH, int SCREEN_HEIGHT)
{
int HALF_SCREEN_WIDTH  = SCREEN_WIDTH/2;
int HALF_SCREEN_HEIGHT = SCREEN_HEIGHT/2;

float AspectRatio = SCREEN_WIDTH/SCREEN_HEIGHT;

float HPC = HALF_SCREEN_WIDTH  / tan((*FOV/2)*OneDeg);
float VPC = AspectRatio * HALF_SCREEN_HEIGHT / tan((*FOV/2)*OneDeg);

Apply_Matrix_To_Vector(m,v);

*sx = ((HPC*v->x / v->z ) + HALF_SCREEN_WIDTH);
*sy = (HALF_SCREEN_HEIGHT - (VPC*v->y / v->z));
}

void main()
{
Camera c;
Matrix m;

clrscr();
puts("************************************************************************\n");
puts("3D Viewing System Tutorial Release 1 - Copright (c) 1998, Gautam N. Lad.");
puts("Released January 10, 1998");
puts("************************************************************************\n");

printf("Enter camera Look From (eg. 3 3 -3): ");
scanf("%f %f %f",&c.LookFrom.x,&c.LookFrom.y,&c.LookFrom.z);

printf("Enter camera Look At (eg. 1 1 1):    ");
scanf("%f %f %f",&c.LookAt.x,&c.LookAt.y,&c.LookAt.z);

Get_Camera_Matrix(&c, &m);

puts("\n\n\nHere's the output...\n");
printf("Camera LookFrom = (%5.2f, %5.2f, %5.2f)\n",c.LookFrom.x,c.LookFrom.y,c.LookFrom.z);
printf("Camera LookAt   = (%5.2f, %5.2f, %5.2f)\n\n",c.LookAt.x,c.LookAt.y,c.LookAt.z);

printf("U = (%5.2f, %5.2f, %5.2f)\n",m.r[0][0],m.r[0][1],m.r[0][2]);
printf("V = (%5.2f, %5.2f, %5.2f)\n",m.r[1][0],m.r[1][1],m.r[1][2]);
printf("N = (%5.2f, %5.2f, %5.2f)\n",m.r[2][0],m.r[2][1],m.r[2][2]);
}
