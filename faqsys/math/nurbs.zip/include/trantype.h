#ifndef _TRANTYPE_
#define _TRANTYPE_

#define ptkcpceps           1.0e-7

#define ptkcpcok            0

typedef enum
{
  PTKEXAXIS = 1,
  PTKEYAXIS,
  PTKEZAXIS
} ptkeaxistype;

#ifdef SUN
#ifdef PHIGS_H_INCLUDED
#define PHIGS_INCLUDE
#endif
#endif

#ifdef VMS
#ifdef PHIGS_H
#define PHIGS_INCLUDE
#endif
#endif

#ifndef PHIGS_INCLUDE

typedef float Pfloat;

#ifdef __TURBOC__
typedef long   Pint;
#else
typedef int   Pint;
#endif

typedef long Plong;
typedef char Pchar;

typedef Pfloat Pmatrix[3][3];
typedef Pfloat Pmatrix3[4][4];

/* Enumerated types */

typedef enum
{
 PPARALLEL,
 PPERSPECTIVE
} Pprojtype;

typedef enum
{
 PPRECONCATENATE,
 PPOSTCONCATENATE,
 PREPLACE
} Pcomptype;

typedef struct
{
  Pfloat x;
  Pfloat y;
} Pvector;

typedef struct
{
  Pfloat x;
  Pfloat y;
  Pfloat z;
} Pvector3;

typedef struct
{
  Pfloat x;
  Pfloat y;
} Ppoint;

typedef struct
{
  Pfloat x;
  Pfloat y;
  Pfloat z;
} Ppoint3;

typedef struct
{
  Pfloat xmin;
  Pfloat xmax;
  Pfloat ymin;
  Pfloat ymax;
} Plimit;

typedef struct
{
  Pfloat xmin;
  Pfloat xmax;
  Pfloat ymin;
  Pfloat ymax;
  Pfloat zmin;
  Pfloat zmax;
} Plimit3;

typedef struct 
{
  Pfloat x;
  Pfloat y;
  Pfloat z;
  Pfloat w;
#ifdef SUN
} Ppoint4;
#endif
#ifdef VMS
} PPpoint4;
#endif


#endif

#endif

/* End. */
