#include <stdio.h>
#include <math.h>

#ifdef __TURBOC__
#include "machine.h"
#include "trantype.h"
#include "tranfns.h"
#elif VMS
#include "ptktype.h"
#include "machine.h"
#include "trantype.h"
#include "tranfns.h"
#elif SUN
#include <malloc.h>
#include "ptktype.h"
#include "machine.h"
#include "trantype.h"
#include "tranfns.h"
#else
#include <phigs.h>
#include <ptk.h>
#endif

#include <nurbtype.h>
#include <nurbfns.h>
