/* include file for complete PHIGS Toolkit */

#ifndef _PTK_
#define _PTK_

#include "machine.h"

#ifdef NURB

/* include transforms and nurbs but nothing else */

#include "ptktype.h"

#include "trantype.h"

#include "tranfns.h"

#include "nurbtype.h"

#include "nurbfns.h"

#endif

/* toolkit constants */

/* toolkit types */

#ifndef NURB

/* include toolkit provided nurb only is not requested */

#include "ptktype.h"

#ifdef VMS
#include "dectype.h"
#endif

#include "trantype.h"

#include "hashtype.h"

#include "plibtype.h"

#include "menutype.h"

#include "topotype.h"

#include "tsltype.h"

#include "windtype.h"

#include "debugtype.h"

#include "viewtype.h"

/* toolkit functions */

#include "tranfns.h"

#include "hashfns.h"

#include "plibfns.h"

#include "cnsfns.h"

#include "menufns.h"

#include "phinfns.h"

#include "topofns.h"

#include "stctfns.h"

#include "elctfns.h"

#include "miscfns.h"

#include "tslfns.h"

#include "windfns.h"

#include "perrfns.h"

#include "debugfns.h"

#include "viewfns.h"

#endif

#ifdef PTKNURB

/* include nurbs with rest of toolkit */

#include "nurbtype.h"

#include "nurbfns.h"

#endif

#endif

/* end of ptk.h */
