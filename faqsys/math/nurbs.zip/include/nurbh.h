#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DIFFERENT 1

#include <ptk.h>

#define PC_DTOR (3.14159/180.0)
#define P_max(A,B) ((A)>(B)? (A):(B))
#define P_min(A,B) ((A)<(B)? (A):(B))
