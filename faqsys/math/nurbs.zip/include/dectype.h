#ifndef _DECTYPE_
#define _DECTYPE_

typedef enum
{
  PFAILURE,
  PSUCCESS
}  Psrchstatus;

typedef enum
{
  PBACKWARD,
  PFORWARD
}  Psrchdir;

typedef struct
{ 
  Pint number;
  Ppoint *points;
} Ppointlst;

typedef struct
{ 
  Pint number;
  Ppoint3 *points;
} Ppointlst3;

#endif

/* end of dectype.h */
