#ifndef _MACHINE_
#define _MACHINE_

/* some trivial macros for dealing with
** old K&R C compilers vs. ANSI C,
** __STDC__ is a built-in macro in ANSI C Compilers.
** (c) Ian Cottam, University of Manchester.
*/
#if __STDC__
#define ARGS(parameters) parameters
#define C(parameter) parameter
#define PreANSI(parameters) /* nothing */
#else
#define ARGS(parameters) ()
#define C(parameter) /* nothing */
#define PreANSI(parameters) parameters;
#endif

#ifdef VMS 

/* Equate SunPHIGS Specific names to DEC PHIGS names*/

#define Ppoint4 PPpoint4 

#define PEL_LOCAL_MODELLING_TRANSFORMATION3 PEL_LOCAL_MODELLING_TRANSFORM3

#define PEL_LOCAL_MODELLING_TRANSFORMATION PEL_LOCAL_MODELLING_TRANSFORM

#define PEL_GLOBAL_MODELLING_TRANSFORMATION3 PEL_GLOBAL_MODELLING_TRANSFORM3

#define PEL_GLOBAL_MODELLING_TRANSFORMATION PEL_GLOBAL_MODELLING_TRANSFORM

#define PEL_ANNOTATION_TEXT_CHARACTER_HEIGHT PEL_ANNOTATION_TEXT_CHARACTER_H

#define PEL_ANNOTATION_TEXT_CHARACTER_UP_VECTOR PEL_ANNOTATION_TEXT_CHARACTER_U

#define PEL_PATTERN_REFERENCE_POINT_AND_VECTORS PEL_PATTERN_REFERENCE_POINT_AND

#define PEL_MODELLING_CLIPPING_VOLUME3 200

#define PEL_MODELLING_CLIPPING_INDICATOR PEL_MODELLING_CLIPPING_INDICATO

#define PEL_RESTORE_MODELLING_CLIPPING_VOLUME PEL_RESTORE_MODELLING_CLIPPING_
 
#define PAH_NORMAL PTH_NORMAL
#define PAH_LEFT   PTH_LEFT
#define PAH_CENTRE PTH_CENTRE
#define PAH_RIGHT  PTH_RIGHT

#define PMARKERSIZE_SCALE_FACTOR PMARKERWIDTH_SCALE_FACTOR

#define PHATCH_HORIZ -4

#define PAN_UNCON PAS_UNCONNECTED

#define Pconfres Pconflictres

#define Pfclass Piclass

#define parallstruct parchiveallstruct

#define parstruct parchivestruct

#define parstructnet parchivestructnet

#define pclosearfile pclosearchivefile

#define pdelallstructar pdelallstructarchive

#define pdelstructar pdelstructarchive

#define pdelstructnetar pdelstructnetarchive

#define popenarfile popenarchivefile

#define pinqancesstruct pinqancestorsstruct

#define pinqarfiles pinqarchivefiles

#define pinqarst pinqarchivest

#define pinqallconfstruct pinqallconflictstruct

#define pinqconfres pinqconflictres

#define pinqconfstructinnet pinqconflictstructinnet

#define pinqdescstruct pinqdecendentsstruct

#define pinqnumdisplaypri pinqnumstructpri

#define psetconfres psetconflictres

#define pinqhilightfilter pinqhighlightfilter

#define psethilightfilter psethighlightfilter

#define pretrievestructids pretrievearchivedstructids

#endif

#endif
